﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseApp.Controllers
{
    public class BookingController : Controller
    {
        public IActionResult Index()
        {

            return View();
            var isConflict = _context.Bookings
    .Any(b => b.VenueID == booking.VenueID &&
              ((booking.StartDate < b.EndDate) && (booking.EndDate > b.StartDate)));

            if (isConflict)
            {
                ModelState.AddModelError("", "This venue is already booked for that time slot.");
                return View(booking);
            }

        }

        public async Task<IActionResult> EnhancedIndex(string search)
        {
            var bookings = from b in _context.Bookings
                           join e in _context.Events on b.EventID equals e.EventID
                           join v in _context.Venues on b.VenueID equals v.VenueID
                           select new BookingDisplayViewModel
                           {
                               BookingID = b.BookingID,
                               EventName = e.Name,
                               VenueName = v.Name,
                               Location = v.Location,
                               StartDate = b.StartDate,
                               EndDate = b.EndDate,
                               Status = b.Status
                           };

            if (!string.IsNullOrEmpty(search))
            {
                bookings = bookings.Where(b =>
                    b.EventName.Contains(search) || b.BookingID.ToString().Contains(search));
            }

            return View(await bookings.ToListAsync());
        }

    }
}
