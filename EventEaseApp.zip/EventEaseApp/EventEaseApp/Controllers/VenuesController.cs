﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseApp.Controllers
{
    public class VenuesController : Controller
    {
        public IActionResult Index()
        {
            return View();
            var hasBookings = _context.Bookings.Any(b => b.VenueID == id);
            if (hasBookings)
            {
                TempData["Error"] = "Cannot delete venue/event linked to active bookings.";
                return RedirectToAction(nameof(Index));
            }

        }
    }
}
